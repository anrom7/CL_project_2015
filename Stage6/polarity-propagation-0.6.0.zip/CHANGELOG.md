A log of changes that are worth mentioning

# v0.6.0
- Code reimplementation (cleaner and commented);
- Introduced the dependence of [JGraphT](http://jgrapht.org/);
- Graphical User Interface available;
- The application no longer support a "config.properties" file;
- The command line now supports arguments.

# v0.5.0
- First public release